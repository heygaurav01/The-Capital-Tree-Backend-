const User = require('./User');
const Feedback = require('./Feedback');

module.exports = {
    User,
    Feedback
};